


<?php $__env->startSection('content'); ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>
 
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">

            <div>
            <?php if(session()->has('bill')): ?>
            <div class="alert alert-success">
            <?php echo e(session()->get('bill')); ?>

            </div>
            <?php endif; ?>
            </div>

             <div>
            <?php if(session()->has('bil')): ?>
            <div class="alert alert-danger">
            <?php echo e(session()->get('bil')); ?>

            </div>
            <?php endif; ?>
            </div>
                <div class="card">
                    <div class="card-header"><?php echo e(__('Bills')); ?></div>

                    <div class="card-body">
                        <form method="post" action="<?php echo e(route("addbill")); ?>">
                            <?php echo csrf_field(); ?>
                            
                            
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="row mb-3">
                                <label for="bill" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Bill Type')); ?></label>

                                <div class="col-md-6">
                                    <input id="bill_type" type="text" class="form-control <?php $__errorArgs = ['bill_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="bill_type" value="<?php echo e(old('bill_type')); ?>" required autocomplete="bill_type" autofocus>

                                    <?php $__errorArgs = ['bill_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="bill_to"
                                    class="col-md-4 col-form-label text-md-end"><?php echo e(__('Bill To')); ?></label>

                                <div class="col-md-6">
                                    <input id="bill_to" type="bill_to" class="form-control <?php $__errorArgs = ['bill_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="bill_to" value="<?php echo e(old('bill_to')); ?>" required autocomplete="bill_to">

                                    <?php $__errorArgs = ['bill_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                           <div class="row mb-3">
                                <label for="amount"
                                    class="col-md-4 col-form-label text-md-end"><?php echo e(__('Amount')); ?></label>

                                <div class="col-md-6">
                                    <input id="amount" type="amount" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="amount" value="<?php echo e(old('amount')); ?>" required autocomplete="amount">

                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="date"
                                    class="col-md-4 col-form-label text-md-end"><?php echo e(__('Bill Date')); ?></label>

                                <div class="col-md-6">
                                    <input id="bill_date" type="date"
                                        class="form-control <?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bill_date"
                                        required autocomplete="bill_date">

                                     <?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Add Bill')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

   

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make((!isset(Auth::user()->id))? 'layouts.app': ((Auth::user()->role_as == 1) ? 'layouts.head' : 'layouts.header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OGOCHUKWUEBUKA\Desktop\laravel-projects\hms\resources\views/billmanag/addbill.blade.php ENDPATH**/ ?>