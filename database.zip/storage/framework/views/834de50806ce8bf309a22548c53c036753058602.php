<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>

<body>
  ;

    <?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
  <div>
        <?php if(session()->has('se')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('se')); ?>


            </div>
        <?php endif; ?>
    </div>



                    <div class="card">
                        <div class="card-header"><?php echo e(__('Seat Allocation')); ?></div>

                        <div class="card-body">
                            <form method="put" action='<?php echo e(url("updateset/" .$seat->id)); ?>'>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                <div class="row mb-3">
                                    <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Student Name')); ?></label>

                                    <div class="col-md-6">
                                        <input id="student_name" type="text" class="form-control <?php $__errorArgs = ['student_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="student_name" value="<?php echo e($seat->student_name); ?>" required autocomplete="student_name" autofocus>

                                        <?php $__errorArgs = ['student_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="block"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Block No')); ?></label>

                                    <div class="col-md-6">
                                        <input id="block_no" type="text"
                                            class="form-control <?php $__errorArgs = ['block_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="block_no"
                                            value="<?php echo e($seat->block_no); ?>" required autocomplete="block_no">

                                        <?php $__errorArgs = ['block_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                  <div class="row mb-3">
                                    <label for="room"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Room No')); ?></label>

                                    <div class="col-md-6">
                                        <input id="room_no" type="text"
                                            class="form-control <?php $__errorArgs = ['room_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="room_no"
                                            value="<?php echo e($seat->room_no); ?>" required autocomplete="block_no">

                                        <?php $__errorArgs = ['room_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="rent"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Monthly Rent')); ?></label>

                                    <div class="col-md-6">
                                        <input id="monthly_rent" type="text"
                                            class="form-control <?php $__errorArgs = ['monthly_rent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="monthly_rent"
                                            value="<?php echo e($seat->monthly_rent); ?>"  required autocomplete="monthly_rent">

                                        <?php $__errorArgs = ['monthly_rent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Save')); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    
</body>

</html>

<?php echo $__env->make((!isset(Auth::user()->id))? 'layouts.app': ((Auth::user()->role_as == 1) ? 'layouts.head' : 'layouts.header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OGOCHUKWUEBUKA\Desktop\laravel-projects\hms\resources\views/student/editseat.blade.php ENDPATH**/ ?>