

    <html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>

<body>


    <?php $__env->startSection('content'); ?>
 
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div>
                        <?php if(session()->has('at')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('at')); ?>


                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="card">
                        <div class="card-header"><?php echo e(__('Update Student Attendance')); ?></div>

                        <div class="card-body">
                            <form method="put" action='<?php echo e(url('updateat/' . $atte->id)); ?>'>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                                <div class="row mb-3">
                                    <label for="name"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Student Name')); ?></label>

                                    <div class="col-md-6">
                                        <input id="student_name" type="text"
                                            class="form-control <?php $__errorArgs = ['student_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="student_name" value="<?php echo e($atte->student_name); ?>" required
                                            autocomplete="student_name" autofocus>

                                        <?php $__errorArgs = ['student_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="date"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Attend Date')); ?></label>

                                    <div class="col-md-6">
                                        <input id="attend_date" type="date"
                                            class="form-control <?php $__errorArgs = ['attend_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="attend_date" value="<?php echo e($atte->attend_date); ?>" required
                                            autocomplete="attend_date">

                                        <?php $__errorArgs = ['attend_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="absence"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Is Absence')); ?></label>

                                    <div class="col-md-6">
                                        <input id="isAbsence" type="text"
                                            class="form-control <?php $__errorArgs = ['isAbsence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="isAbsence"
                                            value="<?php echo e($atte->isAbsence); ?>" required autocomplete="isAbsence">

                                        <?php $__errorArgs = ['isAbsence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="leave"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Is Leave')); ?></label>

                                    <div class="col-md-6">
                                        <input id="isleave" type="text"
                                            class="form-control <?php $__errorArgs = ['isleave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="isleave"
                                            value="<?php echo e($atte->isleave); ?>" required autocomplete="new-isleave">

                                        <?php $__errorArgs = ['isleave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="remark"
                                        class="col-md-4 col-form-label text-md-end"><?php echo e(__('Remark')); ?></label>

                                    <div class="col-md-6">
                                        <input id="remark" type="text" class="form-control" name="remark" required
                                            value="<?php echo e($atte->remark); ?>" autocomplete="remark">
                                    </div>
                                </div>

                                <div class="row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Update Student Attendance')); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>


</body>

</html>

<?php echo $__env->make((!isset(Auth::user()->id))? 'layouts.app': ((Auth::user()->role_as == 1) ? 'layouts.head' : 'layouts.header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OGOCHUKWUEBUKA\Desktop\laravel-projects\hms\resources\views/attendance/editatten.blade.php ENDPATH**/ ?>