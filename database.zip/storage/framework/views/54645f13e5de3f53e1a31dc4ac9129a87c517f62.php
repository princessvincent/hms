

<?php $__env->startSection('content'); ?>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <div>
        <?php if(session()->has('att')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('att')); ?>


            </div>
        <?php endif; ?>
    </div>

    <div>
        <?php if(session()->has('edi')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('edi')); ?>


            </div>
        <?php endif; ?>
    </div>
    <body>
        <div>
            <div class="card">
                <div class="card-header fw-bold"><strong><?php echo e(__('List of all Users')); ?></strong></div>
             <div class="card-body">
             
                <table border="1" class="table">
                    <thead>
                        <tr>
                            <th scope="col">User Name</th>
                            <th scope="col">User Email</th>
                            <th scope="col" colspan="1">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $us1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($use['name']); ?></td>
                                <td><?php echo e($use['email']); ?></td>
                               
                                <td> <a href="<?php echo e(url('editu', $use->id)); ?>" class="btn btn-success">Edit</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

             </div>
            </div>
        </div>



        </div>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(!isset(Auth::user()->id) ? 'layouts.app' : (Auth::user()->role_as == 1 ? 'layouts.head' : 'layouts.header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OGOCHUKWUEBUKA\Desktop\laravel-projects\hms\resources\views/allu.blade.php ENDPATH**/ ?>