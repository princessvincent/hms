;  

<?php $__env->startSection('content'); ?>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <div>
        <?php if(session()->has('de')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('de')); ?>


            </div>
        <?php endif; ?>
    </div>

     <div>
                        <?php if(session()->has( 'edi')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get( 'edi')); ?>


                            </div>
                        <?php endif; ?>
                    </div>




    <body>
        <div>
            <table border="1" class="table">
                <thead>
                    <tr>
                        <th scope="col">Student Name</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Deposit Date</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($deposit['student_name']); ?></td>
                            <td><?php echo e($deposit['amount']); ?></td>
                            <td><?php echo e($deposit['deposit_date']); ?></td>
                            
                            <td> <a href="<?php echo e(url('editd', $deposit->id)); ?>" class="btn btn-secondary">Edit</a></td>
                            <td>
                                <form action="<?php echo e(url('deleted/' . $deposit->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>

                                </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>



        </div>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make((!isset(Auth::user()->id))? 'layouts.app': ((Auth::user()->role_as == 1) ? 'layouts.head' : 'layouts.header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OGOCHUKWUEBUKA\Desktop\laravel-projects\hms\resources\views/student/viewdep.blade.php ENDPATH**/ ?>