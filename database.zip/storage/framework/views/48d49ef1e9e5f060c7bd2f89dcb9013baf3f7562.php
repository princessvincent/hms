 

<?php $__env->startSection('content'); ?>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
<div>
                        <?php if(session()->has('blo')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('blo')); ?>


                            </div>
                        <?php endif; ?>
                    </div>
    <div>
                        <?php if(session()->has( 'edi')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get( 'edi')); ?>


                            </div>
                        <?php endif; ?>
                    </div>

    <body>
        <div>
         <div class="card">
                <div class="card-header"><strong><?php echo e(__('View Block Info')); ?></strong></div>

                <div class="card-body">

                    <table border="1" class="table">
                <thead>
                    <tr>
                        <th scope="col">Block No</th>
                        <th scope="col">Block Name</th>
                        <th scope="col">Description</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($block['block_no']); ?></td>
                            <td><?php echo e($block['block_name']); ?></td>
                            <td><?php echo e($block['description']); ?></td>
                            
                            <td> <a href="<?php echo e(url('editblo', $block->id)); ?>" class="btn btn-secondary">Edit</a></td>
                            <td>
                                <form action="<?php echo e(url('deleteblo/' . $block->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>

                                </form>




                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>







            </table>


                </div>
            </div>
        </div>

           


        </div>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make((!isset(Auth::user()->id))? 'layouts.app': ((Auth::user()->role_as == 1) ? 'layouts.head' : 'layouts.header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OGOCHUKWUEBUKA\Desktop\laravel-projects\hms\resources\views/bloc/viewbloc.blade.php ENDPATH**/ ?>